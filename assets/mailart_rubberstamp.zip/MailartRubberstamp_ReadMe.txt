
=== MAILART RUBBERSTAMP ===
=== MAILART RUBBERSTAMP OBLIQUE ===
=== MAILART RUBBERSTAMP BOLD ===
=== MAILART RUBBERSTAMP BOLD OBLIQUE ===

Keith Bates / K-Type © 2004, 2013 (Regular version 3.1, Bold version 1.1)
www.k-type.com    -    info@k-type.com

Mailart Rubberstamp now has an additional Bold weight and Obliques. The typeface has also been updated with subtle outline improvements, a bigger repertoire of European accented characters, and more consistent, slightly tighter spacing; increase the tracking to recreate the more relaxed, rustic appearance of the earlier version. The fonts are derived from the individually rubber-stamped letters on printed and collaged envelopes received from mailartists, and the typeface Clarendon Condensed.

------------------------------------------------

== Licence Information ==

Licence URL: http://www.k-type.com/licences

------------------------------------------------

== Installing Fonts ==

Fonts are placed in your operating system's Fonts folder and will be made available to all the applications or programs you use.

= Windows =
Put the .ttf or .otf font file into C:\Windows\Fonts, or right-click on the font files > Install

= Mac =
Put the .ttf or .otf font file into /Library/Fonts

------------------------------------------------